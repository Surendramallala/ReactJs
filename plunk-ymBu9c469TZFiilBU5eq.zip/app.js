var app = angular.module('plunker', ['ui.router']);
    app.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/home");
    $stateProvider
        .state("todosView", {
            url: "/todosView",
            templateUrl: "todosView.html",
             controller: "todosViewController"
        })
        .state("Todos", {
            url: "/Todos",
            templateUrl: "Todos.html",
             controller: "MainCtrl"
        })
});

 
app.controller('todosViewController', function($scope,$http) {
  $scope.Edit = function() {
  var id = $scope.editData.employee.id;
};
  
	 $http.get('https://jsonplaceholder.typicode.com/users')
                .success(function(data) {
                    $scope.todoViewData = eval(data);
                   // console.log(data)
                })
                .error(function(data) {
                  //  alert('hi');
                    console.log('Error: ' + data);
                });
});


app.controller('MainCtrl', function($scope,$http) {
  $http.get('https://jsonplaceholder.typicode.com/users')
                .success(function(data) {
                    $scope.todos = eval(data);
                   // console.log(data)
                })
                .error(function(data) {
                  //  alert(data);
                    console.log('Error: ' + data);
                });
});





